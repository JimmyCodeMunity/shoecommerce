<?php
$conn = mysqli_connect('localhost','root','','nollybee');
// if($conn){
//     echo "connection successul";
// }
?>